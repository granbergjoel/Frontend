
for (let i = 0; i < z.value.length; i++) {
    let check;
    check=z.indexOf[i];
    console.log(check)
    if (check=="0"||""1"||"2"||"3"||"4"||"5"||"6"||"7"||"8"||""9"||"0"||"."){
        input= input +z.value; 
        console.log(input)
            }
            else{
        window.alert("Bara siffror är tillåtna, försök igen");
        input="";
    }
    
}